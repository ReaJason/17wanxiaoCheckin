<div align="center"> 
<h1 align="center">
🌈17wanxiaoCheckin
</h1>



[![](https://img.shields.io/badge/author-ReaJason-red "作者")](https://github.com/ReaJason/)
[![](https://img.shields.io/badge/dynamic/json?logo=github&label=GitHub+Followers&labelColor=282c34&color=181717&query=%24.data.totalSubs&url=https%3A%2F%2Fapi.spencerwoo.com%2Fsubstats%2F%3Fsource%3Dgithub%26queryKey%3DReaJason&longCache=true "关注数")](https://github.com/ReaJason)
[![Bilibili](https://img.shields.io/badge/dynamic/json?logo=data%3Aimage%2Fpng%3Bbase64%2CiVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAD7ElEQVR4nO2dW9WrMBCFK6ESkFAJSKiESqgEHCABCZWAhEpAAhL2ecik5dDc%2FpXLBDLfWnlqy0xmJ5BMQnq5CIIgCIIgCIIgCIIgCEIBAHQAemYfrgCunD6wAKAHsEKxALgx+bCQD8%2FS9tmgVqeDr1lLigDgZvDhXso+K9TyTBQRwRJ8AHjntl0Flh5QRAQK%2FmKxPeayWx2OXpBNBKiHvi34b7T2MC4pAvW6twR%2FRwkRKPizBN8CgEcuESj4Lwm+BwBjahEk+H8EwJRKhOaCDzW8e1JLfkUUH1NgmR3XmHffHR1l+72BSs8d7w8U+JDAnZERQMcV+CtUi7dNqFqibB4J7vtrq7xKCuAasbTMXCL4T+5aVk6+2xHUrWdhruAR6HIJcOeu2UHI8zyAe2ytWfEdWz9PVvQ8YAmIQ5dDAB9LFsMVAv8oMO2zAGrC5WNIarRiAuKR9jYEd9pY08aa6uUzIHGRdkgKd8pY0yc1WjEBAqypDYoAG0QAZkQAZkQAZkQAZk4vANQenjsSzS3I%2FwcSbXU5jQBUkRtdf4Rar90v8kSv3+I3ffCCSpk8I%2Fw+lgDkdI%2Fv2rEp2CaiWm1AsDQLlDAD+dlFXLMeAaCSeLZdaSFE5VUQNot38cKuEeBgAsSuG0flVZBmEanbXfNQAsS0fgBYIn2fIu3%2FBBMHEyBmDXlFfA8IzeHb+Ems4WAChKykrVA9ZfsQTL57jXzRg4A5wC%2FA8N4ADiZAZwm2XjW75Qh2KOTfA0p4kygPw28OJcCVgn3nDnYo2EwEYRgGH0qAMyICMCMCMCMCMCMCMCMCMCMCfP3qwHDOQ4AAUekTk8FaBRihJnZdYbvtCGC7LvmkM63GjVDINPFrQgCq5ETXfmMzI90FXzPvfqt7x4rEu%2FZaEcCUxFvgz2zO+BUn6UkoaEEAsptiMSX5e8FoRYCN7cVgb4Vq7U%2FH50Pq4JNP7Qiw8UFnJwcK+tXy+Wj6PLEvPgHSHv5UgwA1IQIwwyFAyLJin9RoxYgAzAQIkPwNmf26busC+OIx5TDqo5nDT+F%2FSS%2F9CYzwb+No49zNy2evkYv0LywGGAXUvp6eSneycqOic0w20k7CNgKE7jJunSGLACTCxF27ylmQc98T5MQUH49swd+I0HPXslLKnT0N+wnkrTKi9JZL%2FL9i1SorMmdeQ4TQQ7OFMxIMzGD45w8nUL1im7efENZLJpgPSw0pfz0cdt4U3230Td%2FTvx2R6d2FrHhEWLkq5PELOMsRPHCPnAZGv1xJteL7jbJiaW3sB2nDvPC%2FosSYvjRQz4cJ6n7KO3rYQL7M+L6nVtfDVRAEQRAEQRAEQRAEIZ5%2FSAXmdfXaoQsAAAAASUVORK5CYII%3D&label=bilibili+fans&labelColor=FE7398&color=282c34&query=%24.data.totalSubs&url=https%3A%2F%2Fapi.spencerwoo.com%2Fsubstats%2F%3Fsource%3Dbilibili%26queryKey%3D233683051&longCache=true)](https://space.bilibili.com/233683051)
<br>
![](https://img.shields.io/github/stars/ReaJason/17wanxiaoCheckin-Actions?style=social "Star数量")
![](https://img.shields.io/github/forks/ReaJason/17wanxiaoCheckin-Actions?style=social "Fork数量")
<br>
![](https://img.shields.io/github/license/ReaJason/17wanxiaoCheckin-Actions "协议")
![](https://img.shields.io/github/v/release/ReaJason/17wanxiaoCheckin-Actions "release版本")

</div>

## ✨项目介绍

&emsp;&emsp;伴随着疫情的到来，学校为了解在校生的健康状况，全校师生都规定在特定的时间进行健康打卡 or 校内打卡，本项目旨在帮助使用完美校园打卡的在校师生提供帮助，每天指定时间进行自动打卡，从每天指定时间打卡的压力中解放出来，全身心地投入到社会主义建设之中去。



## 🔰项目功能

* [x] 完美校园模拟登录获取 token
* [x] 自动获取上次提交的打卡数据，也可通过配置文件修改
* [x] 支持健康打卡和校内打卡
* [x] 支持多人打卡配置，可单人自定义推送，也可统一推送
* [x] 支持邮箱、Qmsg、Server 酱推送打卡消息



## 💦使用方法

- 使用了`requests`、`json5`、`pycryptodome` 第三方库，若本地或服务器未安装请安装 `pip install -r requirements.txt`，腾讯云函数请直接下载 已配置好环境的包 上传即可，打开配置文件进行修改。

- 打开 `conf/user.json` 用户配置文件，依据注释进行修改对应项
  - `phone`、`password`、`device_id`，为登录配置，[device_id 获取](https://lingsiki.lanzous.com/iVUMQml5h7c)
  - `healthy_check` 下为健康打卡配置，请根据截图 [1](https://cdn.jsdelivr.net/gh/LingSiKi/images/img/%E7%AC%AC%E4%B8%80%E7%B1%BB%E5%81%A5%E5%BA%B7%E6%89%93%E5%8D%A1.png)，[2](https://cdn.jsdelivr.net/gh/LingSiKi/images/img/%E7%AC%AC%E4%BA%8C%E7%B1%BB%E5%81%A5%E5%BA%B7%E6%89%93%E5%8D%A1.png) 判断自己属于哪一类
  - `campus_check` 下为校内打卡配置，无论一天有几次校内打卡，每次都会全打（测试）
  - `push` 下为个人推送设置，若全部关闭，则使用下方的配置文件统一推送
- 打开 `conf/push.json` 统一推送配置文件，依据注释进行修改对应项
- 设置完配置文件后，`python index.py` 运行即可




## 🤦‍♂️脚本有问题
* 有问题可提 [issue](https://github.com/ReaJason/17wanxiaoCheckin-Actions/issues)
* 也可加群反馈 [交流群](https://github.com/ReaJason/17wanxiaoCheckin-Actions/issues/30)